//
//  ULAM.h
//  ULAM
//
//  Created by Victor Tavernari on 09/11/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for ULAM.
FOUNDATION_EXPORT double ULAMVersionNumber;

//! Project version string for ULAM.
FOUNDATION_EXPORT const unsigned char ULAMVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ULAM/PublicHeader.h>
